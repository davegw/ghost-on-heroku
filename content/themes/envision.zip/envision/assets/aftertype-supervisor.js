{
  "name": "Envision",
  "slug": "envision",
  "version": "1.0.2",
  "widget-areas": [
  	"widgets-area-a"
  ]
}